#include <unistd.h>
#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>

int main(){

	int pid;
    int tuberia;
    char buffer[256];
	int fin;
	int written;
    
    fin = 0;
            
    mkfifo("./tuberia",0666);
    
    pid = fork();
    
    switch ( pid ){
    
    case -1:
    	perror("fork");
        exit(-1);
        break;
    case 0:
    	printf("Lector de la tuberia\n");
        tuberia = open("./tuberia",O_RDONLY);
        while (!fin)
        {
        	read(tuberia,buffer,256);
            
            if (buffer[0] == 'q')
            	fin = 1;
            else
            	printf("Mensaje recibido(%i): %s\n",getpid(),buffer);
              sleep(5);
         }
         close(tuberia);         
         exit(0);
         break;
    default:
      printf("Escritor de la tuberia\n");
      tuberia = open("./tuberia",O_WRONLY);        
      while(written!=SIGPIPE)
      {
	  //scanf("%s",buffer);
	  fgets(buffer, 256, stdin);
	  size_t length=strlen(buffer)+1;
	 written=( write(tuberia,buffer,length));
	  if (buffer[0] == 'q')
	      fin = 1;           
      }
      printf("Se ha recibido señal SIGPIPE.\n");
      close(tuberia);
      exit(0);
      break;
      
    }
    
}
