#include <unistd.h>
#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/time.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>

#ifndef NHIJOS 
#define NHIJOS 2
#endif

#include <stdlib.h>

// TIpo de datos para las variables que enviamos/leemos por el pipe
typedef struct _dato_t {
	int index;
	int tiempo;
} _t_dato_; 

int terminaHijo = 0;

void * ini_manejador(int signal, void *manejador, int fd)
{
    struct sigaction act;
    struct sigaction old_act;

    int i;

    act.sa_handler = manejador;

    sigemptyset(&act.sa_mask);

    act.sa_flags = SA_RESTART;

    sigaction(signal, &act, &old_act);
}

void closeTub(int index){
  printf("Cerrando la escritura en una tubería %d.\n",index);
  terminaHijo=1;
}

// funcion que ejecutará cada hijo
// index es el indice el bucle for del padre cuando se creó el hijo
// fd es el descriptor de fichero de extremo de escritura de una tubería
void fhijo(int index,int fd) {
 
	int r;
	// Preparar el código para capturar la señal SIGPIPE usando "ini_manejador"
	// La función que trate dicha señal, deberá poner terminaHijo a 1
	ini_manejador(SIGPIPE,closeTub,index);

    	srand(time(NULL));
	while (!terminaHijo) {
		_t_dato_ dato;
		r  = rand() % 15 + 4;
		sleep(r);
		// Escribimos en la tubería el índice y el tiempo dormido
		// creamos una estructura de tipo _t_dato para incluir ambos enteros
		dato.index = index;
		dato.tiempo = r;
		if(write(fd,&dato,sizeof(dato)) == -1){ 
		    fprintf(stderr, "ERROR: write() by child %d.\n", index);
		    exit(-1);
		}		
	}
}

int main(){

    int pid;
    int tfd[2];
    int tpadre[NHIJOS];
    fd_set conjunto;
    int i=0;    
    struct timeval timeout;

    /* CREAR NHIJOS tuberías e hijos. Cada tubería permitirá comunicación unidireccional
  	entre el padre y un hijo (el hijo escribirá y el padre leerá)
   */
    for (i=0; i<NHIJOS; i++) {
	if ( pipe(tfd) == -1 )
	{
	    perror("pipe");
	    exit(-1);
	}
	pid = fork();
  	/* CADA hijo hará una llamada a fhijo. El primer argumento será  i. El segundo, el descriptor del extremo de escritura de su tubería */ 
	switch(pid){
		case -1:	
			perror("fork");
			exit(-1);
			break;
		case 0:
		  /*el hijo escribirá*/
			close(tfd[0]);
			fhijo(i,tfd[1]);
			exit(0);
			break;
		default:
		  /*el padre leerá*/
			close(tfd[1]);
			tpadre[i] = tfd[0];
			break;
	}
	
    int cambios;
    while(1) {
	/* EL proceso padre se queda en un bucle haciendo select para saber cuándo debe leer de alguna tubería/entrada estándar */   	
        FD_ZERO(&conjunto);
   	FD_SET(0, &conjunto); // incluye stdin en el conjunto

 	// incluir resto de descriptores en el conjunto
    	for (i=0;i<NHIJOS;i++) {
		FD_SET(tpadre[i],&conjunto);
    	}

  	// establecer timeout
    	timeout.tv_sec = 15;
    	timeout.tv_usec = 0;

 	//llamada a select
	cambios = select(tpadre[NHIJOS-1]+1,&conjunto,NULL,NULL,&timeout);

	if (cambios == 0) {
		printf("timeout de select\n");
	}
	else {
	  // comprobar si hay algo en la entrada estándar
      	  if (FD_ISSET (0, &conjunto)) {
    		char *line = NULL;
		size_t size= 0;
		getline(&line,&size,stdin);
		// Comprobar si hay que terminar
		// Si es así (porque se recibe exit), cerrar todos los descriptores de lectura para
		// que se genere la señal SIGPIPE para cada hijo
		// Luego, hacer un bucle invocando "wait()" para esperar a que mueran todos los hijos
		line[strlen(line)-1] = '\0';
		printf("Leido: %s\n", line);
		if(strcmp(line,"exit") == 0){
			fflush(NULL);
			for(i=0; i < NHIJOS;i++){
				close(tpadre[i]);
			}
			printf("Cerramos lectura en las tuberías. Esperando finalización de los hijos.\n");
			while (wait(NULL)) {};
			printf("FIN\n");
			exit(0);
		}
    	  } 
    	  for (i = 1; i < tpadre[NHIJOS-1]+1;  ++i) {
		// Comprobar si hay algo en alguna tubería. 
 		// Si es así, leer e imprimir por pantalla
		if(FD_ISSET(i,&conjunto)){
			_t_dato_ dato;
			if(read(i,&dato,sizeof(dato))==-1){
			  fprintf(stderr, "ERROR: read() from child %d\n", i);
			}
			printf("el hijo %d, ha dormido %d s.\n",dato.index,dato.tiempo);
		}
           }
	}
    }
    }
}    
    
    
    
    
    
    
    
    
    
    
    
