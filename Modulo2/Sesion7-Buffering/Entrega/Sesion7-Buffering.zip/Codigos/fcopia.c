#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include <time.h>

#ifndef TAM_BLOQUE
#define TAM_BLOQUE 1
#endif 

// declarar array para almacenar los bytes leidos
char buff[20480];

int main() {

  int   n;
  char  c;
  FILE *fdo, *fdd;

   // mantener este fichero para pruebas iniciales.
  // cambiar por uno mayor para medir tiempos
  fdo = fopen("/dev/zero", "r");

  if( !fdo) {
    perror("open rw"); 
    exit(1);
  }

  // Abrir fichero destino para escritura
  fdd = fopen ("salidarw", "r+");
  if (!fdd) {
	fclose(fdo);
	perror("open salidarw"); 
    	exit(1);
  }

  printf("Comienza la copia con TAM_BLOQUE=%d bytes\n", TAM_BLOQUE); 

  // Bucle de copia: leer TAM_BLOQUE btyes por llamada. Escribir lo leido
  int leido=0;
  while ( 20479 > leido )
  {
	 n=(fread(buff, sizeof(char), TAM_BLOQUE, fdo));
	 if (n == -1) 
	    perror("read: ");
	 leido +=n;
  	 if (fwrite(buff, sizeof(char), n, fdd ) < 0)
     	{
     		perror("Error en write");
		exit(1);
	}
  }            
  fclose(fdd);
  fclose(fdo);
  return 0;
}
