#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include <time.h>

#ifndef TAM_BLOQUE
#define TAM_BLOQUE 1
#endif 

// declarar array para almacenar los bytes leidos
char buff[20480];

int main() {

  int   fdo, fdd,n;
  char  c;

   // mantener este fichero para pruebas iniciales.
  // cambiar por uno mayor para medir tiempos
  fdo = open("/dev/zero", O_RDONLY, 0664);

  if( fdo == -1 ) {
    perror("open fcopia"); 
    exit(1);
  }

  // Abrir fichero destino para escritura
  fdd = open ("salidarw", O_CREAT|O_TRUNC|O_WRONLY/*|O_SYNC*/, 0664);
  if (fdd == -1) {
	close(fdo);
	perror("open salidarw"); 
    	exit(1);
  }

  printf("Comienza la copia con TAM_BLOQUE=%d bytes\n", TAM_BLOQUE); 

  // Bucle de copia: leer TAM_BLOQUE btyes por llamada. Escribir lo leido
  int leido=0;
  while ( 20470 > leido )
  {
	 n=(read(fdo, buff, TAM_BLOQUE));
	 if (n == -1) 
	    perror("read: ");
	 leido +=n;
  	 if (write(fdd, buff, n ) < 0)
     	{
     		perror("Error en write");
		exit(1);
	}
  }            

  

//  printf("tiempo de inicio: %d\n", t_ini);
//  printf("tiempo de fin: %d\n",t_fin );
  close(fdd);
  close(fdo);
  return 0;
}
