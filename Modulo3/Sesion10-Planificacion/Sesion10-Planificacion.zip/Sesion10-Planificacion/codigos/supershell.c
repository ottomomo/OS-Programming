#include <sched.h>
#include <unistd.h>
#include <stdlib.h>

int main()
{

    int max;
    struct sched_param p;
    int sched_policy;

/* Obtencion del valor m�ximo de prioridad de "tiempo real" */
    sched_policy = SCHED_RR;
    max =  = sched_get_priority_max(sched_policy);

/* Fijamos la prioridad del proceso a la m�xima */    
    p.sched_priority = max;    
    if (sched_setscheduler(0, sched_policy, p )==-1){
    	perror("setsechduler");
		exit(-1);
	}

/* Ejecutamos una shell que heredara las propiedades del "padre" */            
	execl("/bin/sh","/bin/sh",(char *) 0 );
/* Comprobar que se heredan las prioridades con el programa prio    */
    return 0;
}    
