#!/bin/bash

if [ -d resultadosPrio2 ]
then
  rm -rf resultadosPrio2
  mkdir resultadosPrio2
else
  mkdir resultadosPrio2
fi

taskset -c 0 ./prio2 -t 0 -p 1 > ./resultadosPrio2/OTHER1.out &
taskset -c 0 ./prio2 -t 1 -p 1 > ./resultadosPrio2/FIFO1.out &
taskset -c 0 ./prio2 -t 1 -p 2 > ./resultadosPrio2/FIFO2.out &
taskset -c 0 ./prio2 -t 1 -p 3 > ./resultadosPrio2/FIFO3.out &
taskset -c 0 ./prio2 -t 1 -p 4 > ./resultadosPrio2/FIFO4.out &
taskset -c 0 ./prio2 -t 0 -p 2 > ./resultadosPrio2/OTHER2.out &
taskset -c 0 ./prio2 -t 0 -p 3 > ./resultadosPrio2/OTHER3.out &
taskset -c 0 ./prio2 -t 1 -p 1 -e > ./resultadosPrio2/FIFO1ES.out &
taskset -c 0 ./prio2 -t 1 -p 15 -e > ./resultadosPrio2/FIFO15ES.out &
taskset -c 0 ./prio2 -t 0 -p 2 -e > ./resultadosPrio2/OTHER2ES.out &
taskset -c 0 ./prio2 -t 0 -p 15 -e > ./resultadosPrio2/OTHER15ES.out &
taskset -c 0 ./prio2 -t 0 -p 1 -e > ./resultadosPrio2/OTHER1ES.out &
taskset -c 0 ./prio2 -t 1 -p 18 > ./resultadosPrio2/FIFO18.out &
taskset -c 0 ./prio2 -t 0 -p 18 > ./resultadosPrio2/OTHER18.out &