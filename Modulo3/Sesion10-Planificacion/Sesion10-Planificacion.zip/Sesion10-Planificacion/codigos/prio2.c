#include <sched.h>
#include <stdio.h>
#include <unistd.h>
#include <getopt.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/time.h>
#include <sys/resource.h>

/* Tipos de planificadores
    SCHED_RR
    SCHED_FIFO
    SCHED_OTHER
*/    
struct tiempo{
	double tu;
	double ts;
	double tt;
	struct rusage  uso;
};

void mide_tiempo (struct tiempo *t)
{
  int            who;
  struct rusage  uso;
  long           tt1, tt2, tt3, tt4;

  who = RUSAGE_SELF;
  
  getrusage(who, &uso);

  tt1 = uso.ru_utime.tv_usec;
  tt2 = uso.ru_utime.tv_sec;
  tt3 = uso.ru_stime.tv_usec;
  tt4 = uso.ru_stime.tv_sec;

  t->tt = ((double)tt1 * 1.0E-6) 
        +  (double)tt2 
        + ((double)tt3 * 1.0E-6) 
        +  (double)tt4;
  
  t->tu = ((double)tt1 * 1.0E-6) + (double)tt2;

  t->ts = ((double)tt3 * 1.0E-6) + (double)tt4;
}

void foo(int e){
  int i,j, fd1,fd2,fd3;
  struct tiempo t1, t3, t4;
  struct tiempo t2;  
  double a = 0.3, b = 0.7, c=1, d=5;
  unsigned long long int p =0;
  char buffer[64]="123456789012345123456789012345123456789012345123456789012345";
  int fd = open("prueba",O_RDWR | O_CREAT, 0666);
  write(fd,buffer,64);
  if(e){
    fd1 = open("prueba",O_RDWR | O_CREAT, 0666);
    fd2 = open("prueba",O_RDWR | O_CREAT, 0666);
    fd3 = open("prueba",O_RDWR | O_CREAT, 0666);
    write(fd,buffer,64);
    write(fd,buffer,64);
    write(fd,buffer,64);
    write(fd,buffer,64);
  }
  mide_tiempo(&t1);

  for( i = 0; i < 99999; i++ ) {
    a = sin(a)*cos(b);
    b = a*cos(a);
    d = sin(a)*cos(b);
    c = sin(a)*cos(b);
    a = sin(a)*cos(b);
    b = a*cos(a);
    d = sin(a)*cos(b);
    c = sin(a)*cos(b);
    lseek(fd,0,SEEK_SET);
    read(fd,buffer,64);
    if(e){
      lseek(fd,0,SEEK_SET);
      read(fd,buffer,64);
      lseek(fd,0,SEEK_SET);
      read(fd,buffer,64);
      lseek(fd,0,SEEK_SET);
      read(fd,buffer,64);
      lseek(fd,0,SEEK_SET);
      read(fd,buffer,64);
      lseek(fd,0,SEEK_SET);
    }
  }

  mide_tiempo(&t2);
  

/* Resultados */

  printf("Tiempo de ejecucion: %f sec \n",
          (t2.tt -t1.tt));
  printf("Tiempo de usuario: %f sec \n",
          (t2.tu -t1.tu));
  printf("Tiempo de sistema: %f sec \n",
          (t2.ts -t1.ts) );
  close(fd);
  if(e){
    close(fd1);
    close(fd2);
    close(fd3);
  }
}

int main(int argc, char* argv[])
{

  /* variables globales de getopt */
  extern char* optarg;
  extern int optind;
  extern int optopt;
  extern int opterr;
  opterr = 0;
  
  struct sched_param p;
  int sched_policy;
  int c, e=0;
  int v;
  if(argc < 5){
      fprintf(stderr,"se debe recibir al menos 2 parametros: -t <n> -p <prio>.\n");
      exit(-1);
  }
  while ((c = getopt (argc, argv, "et:p:")) != -1){

    switch (c){
      case 't':
	//v=(int) ((*optarg) - 48);
	v= atoi(optarg);
	switch(v){
	  case 0:
	    sched_policy=SCHED_OTHER;break;
	  case 1:
	    sched_policy=SCHED_FIFO;break;
	  case 3:
	    sched_policy=SCHED_RR;break;
	  default:
	     fprintf(stderr,"ERROR prio2: parametro -t <n> , n={0,1,2}.\n");
	     exit(-1);
	}break;
      case 'p':
	v=atoi(optarg);
	if((v >= -20) && (v < 20) && sched_policy==SCHED_OTHER){
	  //p.sched_priority = (int) ((*optarg) - 48);
	  p.sched_priority=atoi(optarg);
	}else if((v >= 1) && (v <= 99) && (sched_policy==SCHED_RR || sched_policy==SCHED_FIFO)){
	   //p.sched_priority = (int) ((*optarg) - 48);
	   p.sched_priority=atoi(optarg);
	}else{
	    fprintf(stderr, "ERROR prio2: parametro -p <prio> , si SCHED_OTHER(0): prio=[-20 - +20] , otros: prio=[1 - 99].\n");
	     exit(-1);
	}break;
      case 'e':
	e=1;
	break;
    }
  }
  printf("sched_policy: %d\t prio: %d\n", sched_policy, p.sched_priority);
  if(sched_policy==SCHED_OTHER){
    nice(p.sched_priority);
  }else{
    if(sched_setscheduler(0, sched_policy, &p)==-1){
      perror("sched_setscheduler");
      fprintf(stderr, "error:sched_policy: %d\t prio: %d\n", sched_policy, p.sched_priority);
      exit(-1);
    }
  }
  foo(e);
  return 0;
}
	    
  
