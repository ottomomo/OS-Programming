#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "mytar.h"

char *use;

/** Copy nBytes bytes from the origin file to the destination file.
 *
 * origin: pointer to the FILE descriptor associated with the origin file
 * destination:  pointer to the FILE descriptor associated with the destination file
 * nBytes: number of bytes to copy
 *
 * Returns the number of bytes actually copied or -1 if an error occured.
 */
int copynFile(FILE* origin, FILE* destination, int nBytes)
{

	if (origin == NULL || destination == NULL)
		return -1;

	// Numero de lecturas realizadas.
	int reads = 0;

	// Byte leido.
	int rbyte;

	// Mientras no hallamos leido el final del fichero o
	while( (rbyte = getc(origin)) != EOF && (reads < nBytes) )
	{
		// Si se produce un error en la impresión.
		if( putc(rbyte, destination) == EOF ) return -1;

		// Contamos las lecturas que vamos realizando.
		reads++;
	}

	// Devolvemos el total de lecturas.
	return reads;

}

/** Loads a string from a file.
 *
 * file: pointer to the FILE descriptor 
 * 
 * The loadstr() function must allocate memory from the heap to store 
 * the contents of the string read from the FILE. 
 * Once the string has been properly built in memory, the function returns
 * the starting address of the string (pointer returned by malloc())
 * 
 * Returns: !=NULL if success, NULL if error
 */
char* loadstr(FILE* file)
{

	if (file == NULL)
		return NULL;
	// Caracter leido.
	char c;

	// Longitud de un string.
	int strlength = 0;

	// Leemos caracter a caracter mientras no encontremos el final de
	// un string o nos topemos con el caracter de final de fichero.
	while( ((c = getc(file)) != '\0') && (c != EOF) )
		++strlength;

	// Si no hay nada leido retornamos NULL.
	if( c == EOF ) return NULL;
	else
	{
		// Desplazamos el puntero de lectura.
		fseek(file,-(strlength+1),SEEK_CUR);

		// Reservamos el espacio necesario para el string del nombre.
		char * str = malloc( sizeof(char) * strlength );
		if (str == NULL) return NULL;

		// Guardamos dentro del string el nombre del fichero.
		fread( str ,  sizeof(char) , strlength , file );
		fseek(file,1,SEEK_CUR);

		// Retornamos el nombre del fichero.
		return str;
	}

}

/** Read tarball header and store it in memory.
 *
 * tarFile: pointer to the tarball's FILE descriptor 
 * nFiles: output parameter. Used to return the number
 * of files stored in the tarball archive (first 4 bytes of the header).
 *
 * On success it returns the starting memory address of an array that stores
 * the (name,size) pairs read from the tar file. Upon failure, the function returns NULL.
 */
stHeaderEntry* readHeader(FILE* tarFile,int* nFiles)
{

	if(tarFile==NULL)
		return NULL;

	// Iterador del FOR.
	int i;

	// Tamaño del fichero.
	unsigned int fileSize;

	// Nombre del fichero.
	char* fileName;

	// Si el primer dato no es un número.
	if( fread(nFiles,sizeof(int),1,tarFile) == 0 ) return NULL;

	// 'malloc' reserva espacio para totas las entradas que componen la cabecera.
	stHeaderEntry* headerEntrys = malloc(sizeof(stHeaderEntry) * *(nFiles));

	if ( headerEntrys == NULL ) return NULL;

	for ( i = 0 ; i < *(nFiles) ; i++ )
	{
		// Obtenemos el nombre de la entrada de cabecera correspondiente.
		fileName = loadstr(tarFile);

		// Si alguno de los nombres es NULL el tarball no puede crearse.
		if( fileName == NULL ) return NULL;

		// Obtenemos el tamaño (en bytes) del fichero.
		fread(&fileSize,sizeof(unsigned int),1,tarFile);

		// Establecemos el nombre del fichero actual de la cabecera.
		(headerEntrys+i)->name = fileName;

		// Establecemos el tamaño del fichero actual de la cabecera.
		(headerEntrys+i)->size = fileSize;

	}

	// Devolvemos las entradas que componen la cabecera.
	return headerEntrys;

}

/** Creates a tarball archive 
 *
 * nfiles: number of files to be stored in the tarball
 * filenames: array with the path names of the files to be included in the tarball
 * tarname: name of the tarball archive
 * 
 * On success, it returns EXIT_SUCCESS; upon error it returns EXIT_FAILURE. 
 * (macros defined in stdlib.h).
 *
 * HINTS: First reserve room in the file to store the tarball header.
 * Move the file's position indicator to the data section (skip the header)
 * and dump the contents of the source files (one by one) in the tarball archive. 
 * At the same time, build the representation of the tarball header in memory.
 * Finally, rewind the file's position indicator, write the number of files as well as 
 * the (file name,file size) pairs in the tar archive.
 *
 * Important reminder: to calculate the room needed for the header, a simple sizeof 
 * of stHeaderEntry will not work. Bear in mind that, on disk, file names found in (name,size) 
 * pairs occupy strlen(name)+1 bytes.
 *
 */
int createTar(int nFiles, char *fileNames[], char tarName[])
{
	if (nFiles == 0)
		return EXIT_FAILURE;
	// Reservamos memoria para la cabecera
	stHeaderEntry* headerEntrys = malloc( sizeof(stHeaderEntry) * nFiles );
	if(headerEntrys == NULL)
		return EXIT_FAILURE;
	// Sumamos los bytes que ocupan los numeros de la cabecera
	int headerSize = sizeof(int) + sizeof(unsigned int)* nFiles;
	int i;
	// Sumamos los bytes de los caracteres de cada nombre de fichero mas el
	// caracter \0 que indica fin de linea
	for( i = 0 ; i < nFiles ; ++i)
		headerSize += strlen(fileNames[i]) + 1;

	FILE * tarFile = fopen(tarName, "w");
	if(tarFile == NULL)
		return EXIT_FAILURE;

	fseek(tarFile,headerSize,SEEK_SET);

	FILE * fileToRead;
	int bytesCopied;
	// Copiamos el contenido de los ficheros justo despues del espacio de la
	// cabecera
	for( i = 0 ; i < nFiles ; ++i)
	{
		fileToRead = fopen(fileNames[i], "r");
		if(fileToRead == NULL)
		    return EXIT_FAILURE;
		// Obtenemos el espacio del fichero que copiamos
		bytesCopied = copynFile(fileToRead, tarFile, INT_MAX);
		// Si no se puedo copiar retorno EXIT_FAILURE
		if(bytesCopied==-1) return EXIT_FAILURE;
		// Reservamos espacio para el nombre
		(headerEntrys+i)->name = malloc(sizeof(char)*strlen(fileNames[i]));
		if((headerEntrys+i)->name == NULL)
		    return EXIT_FAILURE;
		// Guardamos el nombre
		strcpy((headerEntrys+i)->name, fileNames[i]);
		// Guardamos el espacio que ocupa el fichero
		(headerEntrys+i)->size = bytesCopied;
		fclose(fileToRead);

	}

	// Me situo al inicio del fichero tar
	fseek(tarFile,0,SEEK_SET);

// Escribimos la cabecera
	fwrite(&nFiles,sizeof(int),1,tarFile);

	for( i = 0 ; i < nFiles ; ++i )
	{
		fwrite((headerEntrys+i)->name,sizeof(char),strlen((headerEntrys+i)->name)+1,tarFile);
		fwrite(&(headerEntrys+i)->size,sizeof(unsigned int),1,tarFile);
		free((headerEntrys+i)->name);
	}

	free(headerEntrys);

	fclose(tarFile);

	return EXIT_SUCCESS;

}

/** Extract files stored in a tarball archive
 *
 * tarName: tarball's pathname
 *
 * On success, it returns EXIT_SUCCESS; upon error it returns EXIT_FAILURE. 
 * (macros defined in stdlib.h).
 *
 * HINTS: First load the tarball's header into memory.
 * After reading the header, the file position indicator will be located at the 
 * tarball's data section. By using information from the 
 * header --number of files and (file name, file size) pairs--, extract files 
 * stored in the data section of the tarball.
 *
 */
int extractTar(char tarName[])
{
	// Iterador del bucle FOR.
	int i;

	// Para contener el número de entradas que posee el fichero tarball.
	int numHeaders;

	// Puntero a descriptor de fichero para los ficheros que vamos a 'descomprimir'.
	FILE* extractFile;

	// Para leer la sección de texto del fichero.
	char* fileContents;

	// Puntero a descriptor de fichero para el fichero tarball.
	FILE* tarballFile = fopen(tarName,"r");

	if( tarballFile == NULL ) return EXIT_FAILURE;

	// Cargamos en memoria los registros de entrada del fichero tarball.
	stHeaderEntry *headerEntrys = readHeader(tarballFile,&numHeaders);

	// Si readHeader detectó algún problema.
	if( headerEntrys == NULL )
	{
		//Cerramos el canal de comunicación con el fichero.
		fclose(tarballFile);

		// Retornamos que la operación en curso falló.
		return EXIT_FAILURE;
	}

	// Obtenemos la ruta del fichero tarball.
	//strncpy(tarPath,tarName, strlen(tarName) - strlen(strrchr(tarName,'/')) );

	// Vamos extrayendo el contenido del tarball en ficheros individuales.
	for( i = 0 ; i < numHeaders ; i++ )
	{
		// Creamos el nuevo fichero correcpondiente en el directorio del tarball.
		extractFile = fopen((headerEntrys+i)->name,"w");

		if( extractFile == NULL )
			return EXIT_FAILURE;

		fileContents = malloc((headerEntrys+i)->size);

		// Leemos el fichero almacenado.
		fread(fileContents,1,(headerEntrys+i)->size,tarballFile);

		// Escribimos el texto en el nuevo fichero.
		fwrite(fileContents,1,(headerEntrys+i)->size,extractFile);

		// Liberamos la memoria reservada.
		free((headerEntrys+i)->name);
		free(fileContents);

		// Cerramos el canal de comunicacion.
		fclose(extractFile);
	}
	free(headerEntrys);
	fclose(tarballFile);

	return EXIT_SUCCESS;

}


/** Extract info files stored in a tarball archive
 *
 * tarName: tarball's pathname
 *
 * On success, it returns EXIT_SUCCESS; upon error it returns EXIT_FAILURE.
 * (macros defined in stdlib.h).
 *
 * HINTS: First load the tarball's header into memory.
 * After reading the header, the file position indicator will be located at the
 * tarball's data section. By using information from the
 * header --number of files and (file name, file size) pairs--, extract files
 * stored in the data section of the tarball.
 *
 */
int
infoTar(char tarName[])
{
	// Complete the function
	FILE * tarball = fopen(tarName, "r");

	if(tarName==NULL)
		return EXIT_FAILURE;

	int numHeaders;
	stHeaderEntry * stHeaders = readHeader(tarball,&numHeaders);

	if(stHeaders==NULL)
		return EXIT_FAILURE;

	int i;
	for(i=0;i<numHeaders;++i) {
		printf("[%d]: %s, size %d Bytes\n",i,stHeaders[i].name,stHeaders[i].size);
	}



	return EXIT_SUCCESS;
}

/** Append a tarball archive
 *
 * nfiles: number of mtar files
 * filenames: array with the path names of the mtar files
 * tarname: name of the tarball archive
 *
 * On success, it returns EXIT_SUCCESS; upon error it returns EXIT_FAILURE.
 * (macros defined in stdlib.h).
 *
 */
int appendTar(int nFiles, char *fileNames[], char tarName[])
{

	int i;

	int headsTotal = 0;

	int headsInside = 0;

	int newheaderSize = 0;

	int newContentSize = 0;

	FILE* tarballFile = fopen(tarName,"rw");

	// CABECERAS DEL ANTIGUO.
	fread(&headsInside,sizeof(int),1,tarballFile);

	// TOTAL DE CABECERAS.
	headsTotal = headsInside + nFiles;

	// CABECERAS DEL TAR ANTIGUO.
	stHeaderEntry* headerEntrys = readHeader(tarballFile,&headsInside);

	// CABECERA NUEVA ENTERA Y CONTENIDO ANTIGUO

	newheaderSize = sizeof(int);

	newheaderSize = sizeof(headerEntrys);

	for( i  = 0 ; i < headsInside ; i++ )
	{
		newheaderSize += ( sizeof(char) * (strlen(headerEntrys[i].name) + 1) + sizeof(unsigned int) );
		newContentSize += headerEntrys[i].size;
	}

	for( i = 0 ; i < nFiles ; i++ )

		newheaderSize += strlen(fileNames[i]) + sizeof(unsigned int);

	fseek(tarballFile, newheaderSize + newContentSize , SEEK_SET );

	stHeaderEntry* newHeader = malloc(newheaderSize);

	for( i = 0 ; i < headsInside ; i++ )
	{
		newHeader[i].name = headerEntrys[i].name;
		newHeader[i].size = headerEntrys[i].size;
	}

	FILE* c;

	for( i = 0 ; i < nFiles ; i++ )
	{
		fopen(fileNames[i],"r");
		newHeader[i+headsInside].size = copynFile(c,tarballFile,INT_MAX);
		newHeader[i+headsInside].name = fileNames[i];
	}

	int sizeOldContent = sizeof(int);

	char* vector[headsInside];

	for( i = 0 ; i < headsInside ; i++ )
	{
		sizeOldContent += sizeof(unsigned int) + strlen(headerEntrys[i].name);
		vector[i] = malloc(headerEntrys[i].size);
	}

	fseek(tarballFile,sizeOldContent,SEEK_SET);

	for( i = 0 ; i < headsInside ; i++ )
	{
		fread(vector[i],headerEntrys[i].size,1,tarballFile);
	}

	fseek(tarballFile,newheaderSize,SEEK_SET);

	for( i = 0 ; i < headsInside ; i++ )
	{
		fwrite(vector[i],headerEntrys[i].size,1,tarballFile);
	}

	fseek(tarballFile,0,SEEK_SET);

	fwrite(&headsTotal,sizeof(int),1,tarballFile);

	for( i = 0 ; i < headsTotal ; i++ )
	{
		fwrite(strcat(newHeader[i].name,"\0"),strlen(newHeader[i].name)+1,1,tarballFile);
		fwrite(newHeader[i].size,sizeof(unsigned int),1,tarballFile);
	}

}

