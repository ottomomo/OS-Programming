#!/bin/sh
 
flag=1 

while [ $flag -eq 1 ] ; do

	echo "Wich sample file do you wish to simulate?: "
	read simulate

	if [ -f "examples/$simulate" ] ; then
		
		flag=0

		simulate="examples/$simulate"
	
	else

		echo "File wasn't found or it was not a regular file."

	fi

done 

flag=1

while [ $flag -eq 1 ] ; do

	echo "How many cpu's would like to use? (1-8): "
	read cores

	if [ $cores -gt 0 ] && [ $cores -lt 9 ] ; then
	
		flag=0
	
	else

		echo "The number of cpu's must be in range (1-8)."

	fi

done 

if [ ! -d "results" ] ; then

	mkdir results

else

	rm -r results
	mkdir results

fi

for nameSched in $(./schedsim -L | tail -n +2) ; do

	for cpu in $(seq 1 $cores) ; do

		./schedsim -n $cpu -s $nameSched -i $simulate

		for i in $(seq 1 $cpu) ; do

			mv "CPU_`expr $i - 1`.log" "results/$nameSched-CPU-`expr $i - 1`.log"
			cd ../gantt-gplot
			./generate_gantt_chart "../schedsim/results/$nameSched-CPU-`expr $i - 1`.log"
			cd ../schedsim/

		done

	done

done
