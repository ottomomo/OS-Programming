#include "sched.h"

struct srtf_data {
	int remaining_ticks_slice;
};

static int task_new_srtf(task_t* t)
{
	struct srtf_data* cs_data=malloc(sizeof(struct srtf_data));

	if (!cs_data) return 1;  /* Cannot reserve memory */

	cs_data->remaining_ticks_slice=t->runnable_ticks_left;
	t->tcs_data=cs_data;
	return 0;
}

static void task_free_srtf(task_t* t)
{
	if (t->tcs_data) {
		free(t->tcs_data);
		t->tcs_data=NULL;
	}
}

static task_t* pick_next_task_srft(runqueue_t* rq,int cpu)
{
	task_t* t=head_slist(&rq->tasks);

	/* Current is not on the rq -> let's remove it */
	if (t)
		remove_slist(&rq->tasks,t);

	return t;
}

/*
pick_next_task() se invocará cuando se deba escoger una nueva tarea para ejecutar
en la CPU. Seleccionará una tarea de la run queue, la eliminará de la run queue y
devolverá dicha tarea. Es la función que realmente lleva a cabo la política de
planificación deseada.
*/
static task_t* pick_next_task_srtf(runqueue_t* rq,int cpu)
{

	// Obtenemos la tarea de la primera que esta para ser procesada en la lista.
	// Toda run_queue tiene una task_list.

	task_t* t = head_slist(&rq->tasks);

	// Si hay una tarea encolada, la sacamos de la run_queue y la devolvemos.
	if (t) remove_slist(&rq->tasks,t);

	return t;

}

static int compare_tasks_cpu_burst(void *t1,void *t2)
{
	task_t* tsk1=(task_t*)t1;
	task_t* tsk2=(task_t*)t2;
	return tsk1->runnable_ticks_left-tsk2->runnable_ticks_left;
}

/*
enqueue_task() se invocará cada vez que debamos encolar una tarea en la run queue
de una CPU, bien porque acaba de crearse, porque sale de un bloqueo o porque se ha
migrado desde otra run queue.
*/
static void enqueue_task_srtf(task_t* t,int cpu, int runnable)
{

	// Obtenemos la runqueue de una determinada CPU.
	// runqueue_t* rq = get_runqueue_cpu(cpu);

	// Cada run queue tiene su propia idle_task que tomará la CPU cuando no haya
	// ninguna tarea runnable, esto es, en disposición de ejecutarse.

	// Si la tarea ya esta en la run_queue o no hay tareas en disposición
	// de ejecutarse acabamos.
	// if(t->on_rq || is_idle_task(t)) return;

	// Si la tarea no esta encolada en la run_queue de la cpu especificada,
	// encolamos dicha tarea.
	// sorted_insert_slist(&rq->tasks,t,1,compare_tasks_cpu_burst);

	/**********************************************************************************************/

	runqueue_t* rq=get_runqueue_cpu(cpu);

	if (t->on_rq || is_idle_task(t)) return;

		if (t->flags & TF_INSERT_FRONT) {
			//Clear flag
			t->flags&=~TF_INSERT_FRONT;
			sorted_insert_slist_front(&rq->tasks, t, 1, compare_tasks_cpu_burst);  //Push task
		} else
			sorted_insert_slist(&rq->tasks, t, 1, compare_tasks_cpu_burst);  //Push task

		/* If the task was not runnable before, check whether a preemption is in order or not */
		if (!runnable) {

			task_t* current=rq->cur_task;

			/* Trigger a preemption if this task has a shorter CPU burst than current */
			if (preemptive_scheduler && !is_idle_task(current) && t->runnable_ticks_left<current->runnable_ticks_left) {
				rq->need_resched=TRUE;
				current->flags|=TF_INSERT_FRONT; /* To avoid unfair situations in the event
	                                                another task with the same length wakes up as well*/
			}

		}

}

/*
steal_task() se invocará cuando se lleve a cabo una migración que exija robar una
tarea de la run queue rq. La tarea escogida se sacará de la run queue y se devolverá como
argumento de salida de la función.
 */
static task_t* steal_task_srtf(runqueue_t* rq,int cpu)
{

	// Devuelve el último elemento de la lista (pero no lo saca de ella).
	task_t* t = tail_slist(&rq->tasks);

	// Removemos de la run_queue la tarea especificada.
	if(t) remove_slist(&rq->tasks,t);

	return t;

}

static void task_tick_srtf(runqueue_t* rq,int cpu)
{
	task_t* current=rq->cur_task;

	if(is_idle_task(current)) return;

	current->runnable_ticks_left--;

	if (current->runnable_ticks_left<=0) rq->need_resched=TRUE; //Force a resched !!
}

sched_class_t srtf_sched= {
  .pick_next_task=pick_next_task_srtf,
  .enqueue_task=enqueue_task_srtf,
  .steal_task=steal_task_srtf,
  .task_tick=task_tick_srtf,
  .task_free=task_free_srtf,
  .task_new=task_new_srtf
};
