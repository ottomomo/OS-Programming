#include "sched.h"

struct ml_data {
	int remaining_ticks_slice_per_level;
	int level;
};

static int task_new_ml(task_t* t)
{
	struct ml_data* data = malloc(sizeof(struct ml_data));

	if (!data) return 1;

	data->level = 1;
	data->remaining_ticks_slice_per_level = 1;

	t->tcs_data=data;

	return 0;
}

static void task_free_ml(task_t* t)
{
	if (t->tcs_data) {
		free(t->tcs_data);
		t->tcs_data=NULL;
	}
}

static task_t* pick_next_task_ml(runqueue_t* rq,int cpu)
{
	task_t* t=head_slist(&rq->tasks);

	/* Current is not on the rq -> let's remove it */
	if (t)
		remove_slist(&rq->tasks,t);

	return t;
}

static int compare_tasks_cpu_ml(void *t1,void *t2)
{
	task_t* tsk1=(task_t*)t1;
	task_t* tsk2=(task_t*)t2;
	struct ml_data * data_tsk1 = (struct ml_data *) tsk1->tcs_data;
	struct ml_data * data_tsk2 = (struct ml_data *) tsk2->tcs_data;
	return data_tsk1->level-data_tsk2->level;
}

static void enqueue_task_ml(task_t* t,int cpu, int runnable)
{

	runqueue_t* rq=get_runqueue_cpu(cpu);

	if (t->on_rq || is_idle_task(t)) return;


	  if (t->flags & TF_INSERT_FRONT) {
	  	//Clear flag
	    t->flags&=~TF_INSERT_FRONT;
	    sorted_insert_slist_front(&rq->tasks, t, 1, compare_tasks_cpu_ml);  //Push task
	  } else
	    sorted_insert_slist(&rq->tasks, t, 1, compare_tasks_cpu_ml);  //Push task

	  struct ml_data * data = (struct ml_data *) t->tcs_data;

	  /* If the task was not runnable before, check whether a preemption is in order or not */
		if (!runnable) {
			task_t* current=rq->cur_task;

			struct ml_data * data_current = (struct ml_data *) current->tcs_data;

			/* Trigger a preemption if this task has a shorter CPU prio than current */
			if (preemptive_scheduler && !is_idle_task(current) && data->level<data_current->level) {
				rq->need_resched=TRUE;
				current->flags|=TF_INSERT_FRONT; /* To avoid unfair situations in the event
	                                                another task with the same length wakes up as well*/
			}
		}


		/*
		if(data->level == 1) {
			data->remaining_ticks_slice_per_level = 1;
		} else if(data->level == 2) {
			data->remaining_ticks_slice_per_level = 2;
		} else {
			data->remaining_ticks_slice_per_level = 5;
		}
		*/

}

static void task_tick_ml(runqueue_t* rq,int cpu)
{
	task_t* current=rq->cur_task;
	struct ml_data* data=(struct ml_data *) current->tcs_data;

	if (is_idle_task(current)) return;

	data->remaining_ticks_slice_per_level--;

	//printf("LEVEL:%d\n",data->level);

	if(data->remaining_ticks_slice_per_level <= 0) {
		if(data->level==1) {
			data->level=2;
			data->remaining_ticks_slice_per_level = 2;
		} else {
			data->level=3;
			data->remaining_ticks_slice_per_level = 5;
		}
		rq->need_resched=TRUE;
	}

}

static task_t* steal_task_ml(runqueue_t* rq,int cpu)
{
	task_t* t=tail_slist(&rq->tasks);

	if (t)
		remove_slist(&rq->tasks,t);

	return t;
}

sched_class_t ml_sched= {
	.task_new=task_new_ml,
	.task_free=task_free_ml,
	.pick_next_task=pick_next_task_ml,
	.enqueue_task=enqueue_task_ml,
	.task_tick=task_tick_ml,
	.steal_task=steal_task_ml
};
