// Obligatorio (PARTE A)

#include <linux/kernel.h> // Se necesita para KERN_INFO
#include <linux/module.h> // Todos los modulos lo requieren
#include <linux/fs.h> // La estructura file_operations esta definida en esta libreria.
#include <asm/uaccess.h> // Para la funcion: copy_to_user
#include <linux/cdev.h> // Para el tipo cdev, que nos permitira ligar las operaciones y el dispositivo.

#include <linux/tty.h> // Para fg_console ( Fore ground console / la consola con el foco (de usuario) activo ).
#include <linux/kd.h> // Para obtener los codigos de operaciones del dispositivo TECLADO (KDSETLED/KDGETLED).
#include <linux/vt_kern.h>
#include <linux/version.h> // Para LINUX_VERSION_CODE y KERNEL_VERSION.

MODULE_LICENSE("GPL"); // Licencia del modulo.
MODULE_DESCRIPTION("chardev_leds"); // Comentario que describe lo que hace el modulo (documentación).

struct tty_driver* kbd_driver = NULL; // Variable en la que almacenaremos el driver/manejador del teclado.

// Prototipos de las funciones.
int init_module(void); // Funcion que se ejecuta al cargarse el modulo en el kernel.
void cleanup_module(void); // Funcion que se ejecuta al descargarse el modulo del kernel.
static int device_open(struct inode *, struct file *);
static int device_release(struct inode *, struct file *);
static ssize_t device_read(struct file *, char *, size_t, loff_t *);
static ssize_t device_write(struct file *, const char *, size_t, loff_t *);

#define SUCCESS 0
#define DEVICE_NAME "chardev_leds"	// Nombre del dispositivo que aparecerá en /proc/devices.
#define BUF_LEN 80 // Maxima longitud del mensaje del dispositivo.

/*
 * Declaramos las variables globales como estáticas, de forma que estas solo peden ser
 * "vistas" desde este archivo.
 */

/*
 * En el kernel Linux el par (major,minor)
 * está representado mediante el tipo dev_t
 */
dev_t start;

/*
 * Para que el driver pueda recibir peticiones de los programas
 * de usuario, debe crear una estructura cdev.
 */
struct cdev* chardev = NULL;

/*
 * ¿¿¿ Esta el dispositivo abierto ???
 * Se usa para prevenir multiples accesos al dispositivo.
 */
static int Device_Open = 0;

// El mensaje que el dispositivo dara cuando se le pregunte.
static char msg[BUF_LEN];

/*
 * Este puntero es inicializado cada vez que el
 * dispositivo es abierto correctamente.
 */
static char* msg_Ptr;

// Contiene el numero de veces que se a abierto el dispositivo de caracteres.
static int counter = 0;

// Declaramos las operaciones que podemos relizar con esta interfaz de dispositivo.
static struct file_operations fops = {
    .read = device_read,
    .write = device_write,
    .open = device_open,
    .release = device_release
};

// Esta funcion se ejecuta cuando se carga el modulo.
int init_module(void)
{

	int ret; // Valor a retornar si no se pudo obterner MAJOR/MINOR.
	int major; // Numero MAJOR ( Tipo / Clase de dispositivo ) asignado a nuestro driver de dispositivo.
    int minor; // Numero MINOR ( Identificador dentro del tipo ) asignado a nuestro dispositivo de caracteres.

    // Reserva el major number y obtiene el rango de minors disponible para el driver.
    // Parametros alloc_chrdev_region():
    // 1) Parámetro de retorno. Primer par (major,minor) que el kernel reserva para el driver.
    // 2) Menor minor a reservar dentro del rango consecutivo que otorga el kernel.
    // 3) Número de minors a reservar para el driver.
    // 4) Nombre del driver. Valor que aparecerá en /proc/devices al cargar el driver.
    if(( ret = alloc_chrdev_region( &start , 0 , 1 , DEVICE_NAME ) ))
    {
        printk( KERN_INFO "MY_DRIVER_SAYS: Can't allocate chrdev_region()\n");
        return ret;
    }

    // Registra el dispositivo.
    // cdev_alloc(): Crea estructura cdev y retorna un puntero no nulo a la misma en caso de éxito.
    if( (chardev = cdev_alloc()) == NULL )
    {

    	printk( KERN_INFO "MY_DRIVER_SAYS: cdev_alloc() failed\n" );

    	// Elimina el dispositivo registrado.
    	// Liberar el rango (major, minor).
        // Parametros  unregister_chrdev_region():
    	// 1) Primer par (major,minor) que el driver había reservado previamente.
    	// 2) Número de minor numbers consecutivos que el driver había reservado.
    	unregister_chrdev_region( start , 1 );

        return -ENOMEM;

    }

    // Asocia interfaz de operaciones del driver a estructura cdev
    cdev_init( chardev , &fops );

    /*
     * cdev_add():
     * Permite que peticiones de programas de usuario sobre el rango
     * de (major,minor) especificado mediante parámetros (1) y (2)
     * sean redirigidas al driver que gestiona la estructura cdev.
	 */
    if(( ret = cdev_add( chardev , start , 1 ) ))
    {

    	printk( KERN_INFO "MY_DRIVER_SAYS: cdev_add() failed\n" );

    	// Decrementa el numero de referencias al dispositivo.
        kobject_put(&chardev->kobj);

        // Elimina el dispositivo registrado.
        // Liberar el rango (major, minor).
        // Parametros  unregister_chrdev_region():
        // 1) Primer par (major,minor) que el driver había reservado previamente.
        // 2) Número de minor numbers consecutivos que el driver había reservado.
        unregister_chrdev_region(start, 1);

        return ret;

    }

    // Obtenemos el numero major mediante la macro MAJOR
    major = MAJOR(start);

    // Obtenemos el numero minor mediante la macro MINOR
    minor = MINOR(start);

    // Mensajes a registrar  en el log del sistema.
    printk( KERN_INFO "MY_DRIVER_SAY: I was assigned major number %d. To talk to\n" , major);
    printk( KERN_INFO "MY_DRIVER_SAY: the driver, create a dev file with\n" );
    printk( KERN_INFO "MY_DRIVER_SAY: 'sudo mknod -m 666 /dev/%s c %d %d'.\n" , DEVICE_NAME , major , minor );
    printk( KERN_INFO "MY_DRIVER_SAY: Try to cat and echo to the device file.\n" );
    printk( KERN_INFO "MY_DRIVER_SAY: Remove the device file and module when done.\n" );

    return SUCCESS;

}

// Esta funcion se ejecuta cuando descargamos el modulo.
void cleanup_module(void)
{

	// Elimina el dispositivo registrado.
    if(chardev) cdev_del(chardev);

    // Elimina el dispositivo registrado.
    // Liberar el rango (major, minor).
    // Parametros  unregister_chrdev_region():
    // 1) Primer par (major,minor) que el driver había reservado previamente.
    // 2) Número de minor numbers consecutivos que el driver había reservado.
    unregister_chrdev_region(start, 1);

}

// Funcion que permite obtener y devolver el manejador del dispositivo.
struct tty_driver* get_kbd_driver_handler(void)
{

	printk( KERN_INFO "MY_DRIVER_SAY: modleds: loading\n" );
    printk( KERN_INFO "MY_DRIVER_SAY: modleds: fgconsole is %x\n" , fg_console ); // Salida en HEX

    /*
     * La librería <linux/version.h> posee la macro KERNEL_VERSION que permite
     * comprobar la version del kernel linux con la ayuda de la macro KERNEL_VERSION_CODE.
     * El motivo de comporobar la version del kernel es que no todos los moodulos seran validos
     * para un tipo de kernel, por eso hemos de comprobar la version.
     * KERNEL_VERSION(major,minor,release)
     * LINUX_VERSION_CODE calcula un numero entero de la version del kernel actual,
     * con KERNEL_VERSION, podemos saber si hemos pasado una determinada version del kernel
     * o por el contrario nuestra version es mas antigua.
     */
	#if( LINUX_VERSION_CODE > KERNEL_VERSION(2,6,32) )

    	/*
    	 * vc_cons[fg_console].d : En linux las terminales/shells/consolas son considerados
    	 * dispositivos ('virtuales'), en este caso estamos accediendo a la consola activa,
    	 * es decir, aquella que tiene el foco del usuario. A partir de aqui podeos acceder
    	 * a muchas propiedades de la consola activa. Estamos accediendo al dispositivo.
    	 * port.tty->driver: Mediante el port (conexion fisica) accedemos al driver/manejador
    	 * de nuestra 'tty' (terminal/consola).
    	 */
    	return vc_cons[fg_console].d->port.tty->driver;

    #else

    	/*
    	 * vc_cons[fg_console].d --> Accedemos a la consola virtual activa.
    	 * vc_tty->driver --> Acceso al driver/manejador de la conexion virtual.
    	 */
    	return vc_cons[fg_console].d->vc_tty->driver;

	#endif

}

/*
 * Establece el estado de los leds pasandole una mascara de bits adecuada.
 * (1) Driver
 * (2) Mascara de bits
 */
static inline int set_leds(struct tty_driver* handler, unsigned int mask)
{

    /*
     * La librería <linux/version.h> posee la macro KERNEL_VERSION que permite
     * comprobar la version del kernel linux con la ayuda de la macro KERNEL_VERSION_CODE.
     * El motivo de comporobar la version del kernel es que no todos los moodulos seran validos
     * para un tipo de kernel, por eso hemos de comprobar la version.
     * KERNEL_VERSION(major,minor,release)
     * LINUX_VERSION_CODE calcula un numero entero de la version del kernel actual,
     * con KERNEL_VERSION, podemos saber si hemos pasado una determinada version del kernel
     * o por el contrario nuestra version es mas antigua.
     */
	#if( LINUX_VERSION_CODE > KERNEL_VERSION(2,6,32) )

		/*
		 * ioctl(): Para realizar operaciones de control.
		 * Permite a una aplicacion controlar o comunicarse con un driver de dispositivo.
		 * (1): Un descriptor de archivos abierto ( stdin 0 , stdout 1 , stderr 2 )
		 * (2): Un numero de codigo de requerimiento (operacion). KDSETLED / KDGETLED
		 * (3): Un valor entero (varia en funcion del driver, operacion que queremos realizar).
		 */
		return ( handler->ops->ioctl ) ( vc_cons[fg_console].d->port.tty , KDSETLED , mask );

    #else

		/*
		 * ioctl(): Para realizar operaciones de control.
		 * Permite a una aplicacion controlar o comunicarse con un driver de dispositivo.
	     * (1): Un descriptor de archivos abierto ( stdin 0 , stdout 1 , stderr 2 ).
		 * (2): ????
		 * (3): Un numero de codigo de requerimiento.
		 * (4): Un valor entero (varia en funcion del driver, operacion que queremos realizar).
		 */
    	return ( handler->ops->ioctl ) ( vc_cons[fg_console].d->vc_tty, NULL, KDSETLED , mask );

    #endif

}

/*
 * Esta funcion es llamada cuando un proceso intenta abrir el fichero del dispositivo
 * Ejemplo: cat /dev/chardev
 */
static int device_open(struct inode *inode, struct file *file)
{

	// Si el dispositivo ya está abierto (Device_Open > 0), devolvemos un error indicando que esta ocupado.
	if(Device_Open) return -EBUSY;

	// Incrementamos el numero de aperturas del fichero (dispositivo).
    Device_Open++;

    // sprintf --> Pasa un string a la variable especificada.
    sprintf( msg , "MY_DRIVER_SAYS: I already told you %d times Hello world!\n" , counter++ );

    // Hacemos que el puntero apunte a nuestro mensaje.
    msg_Ptr = msg;

    /*
     * Incrementa un contador interno del kernel para este módulo.
     * Si el contador es distinto de cero, el módulo no puede
     * eliminarse. Se pueden ver los valores de estos contadores con
     * lsmod (Columna “Used by”).
	 */
    try_module_get(THIS_MODULE);

    return SUCCESS;

}

// Esta funcion es llamada cuando un proceso cierra el fichero del dispositivo.
static int device_release(struct inode *inode, struct file *file)
{

	// Decrementamos el numero de aperturas del fichero (dispositivo).
	Device_Open--;

   /*
    * Decrementa un contador interno del kernel para este módulo.
    * Si el contador es distinto de cero, el módulo no puede
    * eliminarse. Se pueden ver los valores de estos contadores con
    * lsmod (Columna “Used by”).
    */
    module_put(THIS_MODULE);

    return 0;

}

/*
 * Esta funcion es llamada cuando un proceso ( el cual abrio el fichero del dispositivo )
 * trata de leer del dispositivo.
 * (1) Puntero a estructura file (modo,posicion,flags,count,f_next,f_prev,file_operations,f_inode,etc)
 * (2) Buffer a llenar con datos.
 * (3) Tamaño del buffer
 * (4) ???
 */
static ssize_t device_read(struct file *filp, char *buffer,	size_t length, loff_t * offset)
{

	// Numero de bytes que han sido escritos en el buffer.
    int bytes_to_read = length;

    // Si estamos en el final del mensaje, retornamos 0 indicando que hemos llegado al EOF.
    if(*msg_Ptr == 0) return 0;

    // Si los caracteres leidos superan el tamaño del mensaje en bytes,
    // igualo los bytes leidos a la longitud del mensaje.
    if(bytes_to_read > strlen(msg_Ptr)) bytes_to_read = strlen(msg_Ptr);

    // Transferimos los datos al buffer del usuario.
    // (1) Destino.
    // (2) Origen.
    // (3) Bytes a copiar.
    if(copy_to_user(buffer,msg_Ptr,bytes_to_read)) return -EFAULT;

    /* Update the pointer for the next read operation */
    msg_Ptr += bytes_to_read;

    // La operacion de lectura devuelve el numero de bytes copiados en el buffer del usuario.
    return bytes_to_read;

}

/*
 * Esta funcion se llama cuando un proceso intenta escribir en el fichero del dispositivo.
 * Por ejemplo: echo "hi" > /dev/chardev
 */
static ssize_t device_write(struct file *filp, const char *buff, size_t len, loff_t * off)
{

	int i;

	// Mascara de bits para indicar que leds se han de iluminar.
	int mascara = 0x00;

	// En esta copia local cargamos lo escrito por el usuario.
	char messageFromUser[BUF_LEN];

	// Si no se pudo drealizar la copia tenemos que devolver un error.
	if(copy_from_user(messageFromUser,buff,len)) return -EFAULT;

	// Si hemos leido entre 1 y 3 bytes.
	if( len > 0 || len < 4 )
	{

		for( i = 0 ; i < len ; ++i )
		{

			// Simulamos una mascara binaria.
			if( messageFromUser[i] == '1' )
			{
				mascara = mascara | 0x02; // Numeros
			}
			else if( messageFromUser[i] == '2' )
			{
				mascara = mascara | 0x04; // Mayusculas
			}
			else if( messageFromUser[i] == '3' )
			{
				mascara = mascara | 0x01; // Scroll
			}

		}

	}

	// Obtenemos el driver del teclado.
	kbd_driver = get_kbd_driver_handler();

	// Encendemos los leds correspondientes.
	set_leds( kbd_driver , mascara );

	// Devolvemos la longitud en bytes de lo leido.
	return len;

}
