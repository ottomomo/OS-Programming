// Obligatorio (Parte B)

//***************************************************************************
// Daniel Calle Sanchez
// Manuel Guerrero Moñús
//***************************************************************************
// El programa ha de ejecutarse en modo privilegiado (sudo/su)
// El programa puede compilarse con:  gcc -Wall -g leds_user.c -o leds_user
//***************************************************************************

#include <stdio.h>
#include <fcntl.h>

int main(void)
{

	int i;

	int j;

	int op;

	char input[3];

	int bytes_writed;

	int fileDescriptor;

	// Intentamos abrir el fichero de dispositivo, en caso de error cerramos la aplicacion.
	if( (fileDescriptor = open("/dev/chardev_leds",O_RDWR)) < 0 ) return -1;

	do
	{

		printf("1) Gusanito.\n2) Contador binario.\n3) Cruzarse.\n4) Salir.\nElige una opcion: ");

		scanf("%d",&op);

		switch(op)
		{

			case 1: // ************** GUSANITO ************************************

				for( i = 0 ; i < 4 ; ++i )
				{

					for( j = 0 ; j < 3 ; ++j )
					{

						// Vamos alternando los led en cada buelta.
						switch(j)
						{
							case 0: strcpy(input,"1"); break;
							case 1: strcpy(input,"2"); break;
							case 2: strcpy(input,"3"); break;
						}

						// Si es posible, intentamos establecer los led activos.
						if( (bytes_writed = write(fileDescriptor,input,strlen(input))) < 0 ) return -1;

						// Para el programa 1 segundo.
						sleep(1);

					}

				}

				// Apagamos todos los leds.
				if( (bytes_writed = write(fileDescriptor,"0",1)) < 0 ) return -1;

			break;
			case 2: // ****************** CONTADOR BINARIO ***********************************

				for( i = 0 ; i < 8 ; ++i )
				{

					// Planificamos el orden en el que se ha de mostrar el contador binario.
					switch(i)
					{
						case 1: strcpy(input,"3"); break;
						case 2: strcpy(input,"2"); break;
						case 3: strcpy(input,"23"); break;
						case 4: strcpy(input,"1"); break;
						case 5: strcpy(input,"13"); break;
						case 6: strcpy(input,"12"); break;
						case 7: strcpy(input,"123"); break;
						default: strcpy(input,"0"); break;
					}

					// Establecemos a ON los led correspondientes.
					if( (bytes_writed = write(fileDescriptor,input,strlen(input))) < 0 ) return -1;

					// Paramos el programa durante 1 segundo.
					sleep(1);

				}

				// Ponemos todos los leds en OFF.
				if( (bytes_writed = write(fileDescriptor,"0",1)) < 0 ) return -1;

			break;
			case 3: // ******************** CRUZARSE **************************************

				for( i = 0 ; i < 4 ; ++i )
				{

					for( j = 0 ; j < 3 ; ++j )
					{

						// Indicamos como va a producirse el cruce de los leds.
						switch(j)
						{
							case 0: strcpy(input,"13"); break;
							case 1: strcpy(input,"2"); break;
							case 2: strcpy(input,"13"); break;
						}

						// Establecemos a ON los leds correspondientes.
						if( (bytes_writed = write(fileDescriptor,input,strlen(input))) < 0 ) return -1;

						// Paramos un segundo el programa.
						sleep(1);

					}

				}

				// Ponemos todos los leds en OFF.
				if( (bytes_writed = write(fileDescriptor,"0",1)) < 0 ) return -1;

			break;

		}

	} while(op != 4);

	// Intentamos cerrar el fichero de dispositivo, en caso de haber problemas devolvemos un error.
	if( close(fileDescriptor) < 0 ) return -1;

	return 0;

}
