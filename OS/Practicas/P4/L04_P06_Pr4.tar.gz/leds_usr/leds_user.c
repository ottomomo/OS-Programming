#include <linux/input.h>
#include <fcntl.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>

void beep(int seleccionado);
void leds(int aux);

int main() {
    int sigue=0;
    
    // Bucle de la aplicacion
    while(sigue<1) {
        
        
        // G G A G C B | G G A G D C | G G G^ E C B A | F F E C D C
        // 4 4 5 4 7 6   4 4 5 4 1 0   4 4 4  2 0 6 5   3 3 2 0 1 0

        
// int numero=0;
// while(numero++ < 100)
//     leds(numero%8);


         leds(4);beep(4);leds(4);beep(4);leds(5);beep(5);leds(4);beep(4);leds(7);beep(7);leds(6);beep(6);
        
         leds(4);beep(4);leds(4);beep(4);leds(5);beep(5);leds(4);beep(4);leds(1);beep(1);leds(0);beep(0);
         
         leds(4);beep(4);leds(4);beep(4);leds(4);beep(4);leds(2);beep(2);leds(0);beep(0);leds(6);beep(6);leds(5);beep(5);

         leds(3);beep(3);leds(3);beep(3);leds(2);beep(2);leds(0);beep(0);leds(1);beep(1);leds(0);beep(0);
        
        sigue++;
    }
    return 0;
}


void leds(int aux){
    aux = aux % 8;
    int file =-1;
    char datos[3];
    int err=-2;
    size_t tam=0;
    if ((file = open("/dev/chardev_leds",  O_WRONLY)) <0) {
		printf("The file /dev/chardev_leds could not be opened");
		return ;
	}
	

    datos[0]='0';
    datos[1]='0';
    datos[2]='0';
            
	switch(aux) {
        case 0:
            break;
        case 1:
            datos[0]='1';
            tam=1*sizeof(char);
            break;
        case 2:
            datos[0]='2';
            tam=1*sizeof(char);
            break;
        case 3:          
            datos[0]='1';
            datos[1]='2';
            tam=2*sizeof(char);
            break;
        case 4:            
            datos[0]='3';
            tam=1*sizeof(char);
            break;
        case 5:
            datos[0]='1';
            datos[1]='3';
            tam=2*sizeof(char);
            break;
        case 6:            
            datos[0]='2';
            datos[1]='3';
            tam=2*sizeof(char);
            break;
        case 7:
            datos[0]='1';
            datos[1]='2';
            datos[2]='3';
            tam=3*sizeof(char);
            break;
    }
    
    printf(" Holaaaa %s - %d",datos, tam);
   if((err= write(file, datos, tam))<0){
       close (file); 
       printf("The file /dev/chardev_leds could not be writed %d \n ", err);
		return ;
    }
    close(file);
}

void  beep(int seleccionado){
     switch(seleccionado) {
                case 0:// C         261.6
                    system("speaker-test -t sine -f 261.6 -l 1 -p 1");
                    break;
                case 1:// D         293.7
                    system("speaker-test -t sine -f 293.7 -l 1 -p 1");
                    break;
                case 2:// E         329.6
                    system("speaker-test -t sine -f 329.6 -l 1 -p 1");
                    break;
                case 3:// F         349.2
                    system("speaker-test -t sine -f 349.2 -l 1 -p 1");
                    break;
                case 4:// G         392.0
                    system("speaker-test -t sine -f 392.0 -l 1 -p 1");
                    break;
                case 5:// A         440.0
                    system("speaker-test -t sine -f 440.0 -l 1 -p 1");
                    break;
                case 6:// B         493.9
                    system("speaker-test -t sine -f 493.9 -l 1 -p 1");
                    break;
                case 7:// C         523.2
                    system("speaker-test -t sine -f 523.2 -l 1 -p 1");
                    break;
            }
}
        // G G A G C B | G G A G D C | G G G^ E C B A | F F E C D C
        // 4 4 5 4 7 6   4 4 5 4 1 0   4 4 4  2 0 6 5   3 3 2 0 1 0
